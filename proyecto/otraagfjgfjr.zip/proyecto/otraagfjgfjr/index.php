<?php echo '<center><h1>Bienvenido a otraagfjgfjr</h1></center>'; ?>
